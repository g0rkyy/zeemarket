<?php
// functions.php
if (!isset($_SESSION)) {
    session_start(); // Inicia a sessão se ainda não estiver iniciada
}

require_once 'config.php';

// Função de login
function login($email, $senha) {
    global $conn;
    
    $stmt = $conn->prepare("SELECT id, name, password FROM users WHERE email = ?");
    if (!$stmt) {
        return "Erro na preparação da consulta: " . $conn->error;
    }
    
    $stmt->bind_param("s", $email);
    if (!$stmt->execute()) {
        return "Erro ao executar a consulta: " . $stmt->error;
    }
    
    $result = $stmt->get_result();
    
    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        if (password_verify($senha, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['name'];
            return true;
        }
    }
    return "Credenciais inválidas!";
}

// Função de cadastro
function cadastrarUsuario($nome, $email, $senha) {
    global $conn;
    
    // Verifica se email já existe
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
    if (!$stmt) {
        return "Erro na preparação da consulta: " . $conn->error;
    }
    
    $stmt->bind_param("s", $email);
    if (!$stmt->execute()) {
        return "Erro ao verificar e-mail: " . $stmt->error;
    }
    
    if ($stmt->get_result()->num_rows > 0) {
        return "E-mail já cadastrado!";
    }

    // Cadastra novo usuário
    $senhaHash = password_hash($senha, PASSWORD_DEFAULT);
    $stmt = $conn->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
    if (!$stmt) {
        return "Erro na preparação do cadastro: " . $conn->error;
    }
    
    $stmt->bind_param("sss", $nome, $email, $senhaHash);
    return $stmt->execute() ? true : "Erro ao cadastrar: " . $stmt->error;
}

// Verificação de login
function verificarLogin() {
    if (!isset($_SESSION['user_id'])) {
        header("Location: login.php");
        exit();
    }
}

// Logout
function logout() {
    $_SESSION = [];
    if (session_status() === PHP_SESSION_ACTIVE) {
        session_destroy();
    }
    header("Location: login.php");
    exit();
}
?>