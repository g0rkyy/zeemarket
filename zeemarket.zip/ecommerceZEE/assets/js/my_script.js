function esgotado(){
    alert("Produto esgotado!");
}

