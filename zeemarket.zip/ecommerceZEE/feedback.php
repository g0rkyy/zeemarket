<?php 
require_once 'includes/functions.php';
require_once 'includes/config.php';
// Verifica se a conexão foi estabelecida
if (!$conn) {
    die("Erro na conexão com o banco de dados: " . mysqli_connect_error());
}

$mensagem_sucesso = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = htmlspecialchars($_POST['name']);
    $email = filter_var($_POST['email'], FILTER_VALIDATE_EMAIL);
    $feedback = htmlspecialchars($_POST['feedback']);
    $rating = (int)$_POST['rating'];

    if (!$email || $rating < 1 || $rating > 5) {
        die("Dados inválidos");
    }

    try {
        // Verifica se a tabela existe
        $table_check = $conn->query("SHOW TABLES LIKE 'feedback'");
        if ($table_check->num_rows == 0) {
            die("A tabela feedback não existe no banco de dados");
        }

        $stmt = $conn->prepare("INSERT INTO feedback (nome, email, feedback, rating) VALUES (?, ?, ?, ?)");
        if (!$stmt) {
            die("Erro na preparação da query: " . $conn->error);
        }
        
        $stmt->bind_param("sssi", $nome, $email, $feedback, $rating);
        
        if ($stmt->execute()) {
            $mensagem_sucesso = "Feedback enviado com sucesso!";
            // Limpa as variáveis para limpar o formulário
            $nome = $email = $feedback = '';
            $rating = null;
        } else {
            die("Erro ao enviar feedback: " . $stmt->error);
        }
    } catch (Exception $e) {
        die("Erro no banco de dados: " . $e->getMessage());
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>ZeeMarket - Feedback</title>
    <link rel="icon" href="images/capsule.png" type="image/x-icon">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="ZeeMarket - Feedback">
    <link rel="stylesheet" href="assets/css/bootstrap.css">
    <link rel="stylesheet" href="assets/css/feedback.css">
    <link rel="stylesheet" href="assets/bootstrap-icons/font/bootstrap-icons.css">
</head>
<body>
    <div id="feedback-container" class="container mt-5">
        <h1 class="text-center">Feedback</h1>
        
        <?php if (!empty($mensagem_sucesso)): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo $mensagem_sucesso; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        
        <div id="nav-container">
            <ul class="nav navbar justify-content-center">
                <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="faq.php">FAQ</a></li>
                <li class="nav-item"><a class="nav-link" href="signup.php">SignUp</a></li>
                <li class="nav-item"><a class="nav-link" href="login.php">Login</a></li>
                <li class="nav-item"><a class="nav-link active" href="feedback.php">Feedback</a></li>
            </ul>
        </div>
        
        <form id="feedback-form" method="post">
            <div class="mb-3">
                <label for="name" class="form-label">Name</label>
                <input type="text" class="form-control" id="name" name="name" required 
                       placeholder="Enter your name" value="<?php echo isset($nome) ? $nome : ''; ?>">
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control" id="email" name="email" required 
                       placeholder="Enter your email" value="<?php echo isset($email) ? $email : ''; ?>">
            </div>
            <div class="mb-3">
                <label for="feedback" class="form-label">Feedback</label>
                <textarea class="form-control" id="feedback" name="feedback" rows="5" required 
                          placeholder="Enter your feedback"><?php echo isset($feedback) ? $feedback : ''; ?></textarea>
            </div>
            <div class="mb-3">
                <label for="rating" class="form-label">Rating</label>
                <select class="form-select" id="rating" name="rating" required>
                    <option value="" disabled <?php echo !isset($rating) ? 'selected' : ''; ?>>Select a rating</option>
                    <option value="1" <?php echo (isset($rating) && $rating == 1) ? 'selected' : ''; ?>>1 - Poor</option>
                    <option value="2" <?php echo (isset($rating) && $rating == 2) ? 'selected' : ''; ?>>2 - Fair</option>
                    <option value="3" <?php echo (isset($rating) && $rating == 3) ? 'selected' : ''; ?>>3 - Good</option>
                    <option value="4" <?php echo (isset($rating) && $rating == 4) ? 'selected' : ''; ?>>4 - Very Good</option>
                    <option value="5" <?php echo (isset($rating) && $rating == 5) ? 'selected' : ''; ?>>5 - Excellent</option>
                </select>
            </div>
            <div class="mb-3">
                <button id="button-submit" type="submit" class="btn btn-primary">Submit</button>
            </div>
        </form>
    </div>

    <script src="assets/js/bootstrap.bundle.min.js"></script>
</body>
</html>