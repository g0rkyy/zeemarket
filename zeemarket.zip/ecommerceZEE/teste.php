<?php
echo "Hello, PHP!";
?>
